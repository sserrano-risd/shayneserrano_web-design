$("document").ready(function(){
  
})